(() => {
  "use strict";

  const translations = {
    hi: {
      appName:"श्री गणेश डिजिटल पूजा धाम", byClinic:"गणेश क्लीनिक की ओर से भक्तिमय उपहार",
      language:"भाषा", heroTitle:"श्री गणेश डिजिटल पूजा धाम", hint:"नीचे दिए गए विकल्पों से पूजा प्रारंभ करें",
      diya:"दीपक जलाएँ", flower:"फूल अर्पित करें", bell:"घंटी बजाएँ", aarti:"आरती करें",
      incense:"🕯️ धूप", prasad:"🍬 मोदक भोग", chant:"🕉️ मंत्र जाप", reset:"↺ फिर से शुरू",
      aartiStarted:"आरती प्रारंभ हो गई है", aartiText:"जय गणेश देवा…<br>मंगलमूर्ति मोरया…<br>गणपति बप्पा मोरया 🙏",
      soundOn:"🔊 ध्वनि चालू", soundOff:"🔇 ध्वनि बंद", finishAarti:"आरती पूर्ण करें",
      ready:"आपकी पूजा के लिए विकल्प तैयार हैं। 🙏", wishTitle:"🙏 अपनी मनोकामना अर्पित करें",
      wishBtn:"मनोकामना अर्पित करें", privacy:"आपकी मनोकामना इस डिवाइस पर ही रहती है और सार्वजनिक नहीं की जाती।",
      progress:"पूजा अनुभव", clinicTitle:"गणेश क्लीनिक", clinicMessage:"आपके जीवन में सुख, शांति और स्वास्थ्य बना रहे।",
      hours:"समय: सुबह 9:00–1:00 • शाम 5:00–10:00", footer:"गणपति बप्पा मोरया",
      diyaMsg:"दीपक प्रज्वलित हो गया। मंगल प्रकाश आपके जीवन में बना रहे। 🪔",
      flowerMsg:"गणेशजी को पुष्प अर्पित किए गए। 🌸", bellMsg:"घंटी की मंगल ध्वनि गूँज उठी। 🔔",
      incenseMsg:"धूप अर्पित की गई। वातावरण पवित्र और शांत रहे। 🕯️",
      prasadMsg:"गणेशजी को मोदक का भोग अर्पित किया गया। 🍬",
      chantMsg:"ॐ गं गणपतये नमः — मंत्र जाप पूर्ण। 🕉️",
      wishMsg:"आपकी मनोकामना श्रद्धापूर्वक अर्पित की गई। गणपति बप्पा मोरया! 🙏",
      emptyWish:"कृपया अपनी मनोकामना लिखें। 🙏", complete:"आपकी पूजा पूर्ण हुई। सुख, शांति और स्वास्थ्य की मंगलकामना। 🌺",
      placeholder:"अपनी मनोकामना यहाँ लिखें…"
    },
    gu: {
      appName:"શ્રી ગણેશ ડિજિટલ પૂજા ધામ", byClinic:"ગણેશ ક્લિનિક તરફથી ભક્તિપૂર્ણ ભેટ",
      language:"ભાષા", heroTitle:"શ્રી ગણેશ ડિજિટલ પૂજા ધામ", hint:"નીચેના વિકલ્પોથી પૂજા શરૂ કરો",
      diya:"દીવો પ્રગટાવો", flower:"ફૂલ અર્પણ કરો", bell:"ઘંટ વગાડો", aarti:"આરતી કરો",
      incense:"🕯️ ધૂપ", prasad:"🍬 મોદક ભોગ", chant:"🕉️ મંત્ર જાપ", reset:"↺ ફરી શરૂ કરો",
      aartiStarted:"આરતી શરૂ થઈ ગઈ છે", aartiText:"જય ગણેશ દેવા…<br>મંગલમૂર્તિ મોરયા…<br>ગણપતિ બાપ્પા મોરયા 🙏",
      soundOn:"🔊 ધ્વનિ ચાલુ", soundOff:"🔇 ધ્વનિ બંધ", finishAarti:"આરતી પૂર્ણ કરો",
      ready:"તમારી પૂજા માટે વિકલ્પો તૈયાર છે. 🙏", wishTitle:"🙏 તમારી મનોકામના અર્પણ કરો",
      wishBtn:"મનોકામના અર્પણ કરો", privacy:"તમારી મનોકામના આ ઉપકરણ પર જ રહે છે અને જાહેર કરવામાં આવતી નથી.",
      progress:"પૂજા અનુભવ", clinicTitle:"ગણેશ ક્લિનિક", clinicMessage:"તમારા જીવનમાં સુખ, શાંતિ અને સ્વાસ્થ્ય જળવાઈ રહે.",
      hours:"સમય: સવારે 9:00–1:00 • સાંજે 5:00–10:00", footer:"ગણપતિ બાપ્પા મોરયા",
      diyaMsg:"દીવો પ્રગટ્યો. મંગળ પ્રકાશ તમારા જીવનમાં રહે. 🪔",
      flowerMsg:"ગણેશજીને ફૂલ અર્પણ કરવામાં આવ્યા. 🌸", bellMsg:"ઘંટનો મંગળ ધ્વનિ ગુંજી ઉઠ્યો. 🔔",
      incenseMsg:"ધૂપ અર્પણ કરવામાં આવી. વાતાવરણ પવિત્ર અને શાંત રહે. 🕯️",
      prasadMsg:"ગણેશજીને મોદકનો ભોગ અર્પણ કરવામાં આવ્યો. 🍬",
      chantMsg:"ૐ ગં ગણપતયે નમઃ — મંત્ર જાપ પૂર્ણ. 🕉️",
      wishMsg:"તમારી મનોકામના શ્રદ્ધાપૂર્વક અર્પણ કરવામાં આવી. ગણપતિ બાપ્પા મોરયા! 🙏",
      emptyWish:"કૃપા કરીને તમારી મનોકામના લખો. 🙏", complete:"તમારી પૂજા પૂર્ણ થઈ. સુખ, શાંતિ અને સ્વાસ્થ્યની મંગલકામના. 🌺",
      placeholder:"તમારી મનોકામના અહીં લખો…"
    },
    mr: {
      appName:"श्री गणेश डिजिटल पूजा धाम", byClinic:"गणेश क्लिनिकतर्फे भक्तीपूर्ण भेट",
      language:"भाषा", heroTitle:"श्री गणेश डिजिटल पूजा धाम", hint:"खालील पर्यायांमधून पूजा सुरू करा",
      diya:"दिवा लावा", flower:"फूल अर्पण करा", bell:"घंटा वाजवा", aarti:"आरती करा",
      incense:"🕯️ धूप", prasad:"🍬 मोदक नैवेद्य", chant:"🕉️ मंत्रजप", reset:"↺ पुन्हा सुरू करा",
      aartiStarted:"आरती सुरू झाली आहे", aartiText:"जय गणेश देवा…<br>मंगलमूर्ती मोरया…<br>गणपती बाप्पा मोरया 🙏",
      soundOn:"🔊 ध्वनी सुरू", soundOff:"🔇 ध्वनी बंद", finishAarti:"आरती पूर्ण करा",
      ready:"आपल्या पूजेसाठी पर्याय तयार आहेत. 🙏", wishTitle:"🙏 आपली मनोकामना अर्पण करा",
      wishBtn:"मनोकामना अर्पण करा", privacy:"आपली मनोकामना या उपकरणावरच राहते आणि सार्वजनिक केली जात नाही.",
      progress:"पूजा अनुभव", clinicTitle:"गणेश क्लिनिक", clinicMessage:"आपल्या जीवनात सुख, शांती आणि आरोग्य नांदो.",
      hours:"वेळ: सकाळी 9:00–1:00 • संध्याकाळी 5:00–10:00", footer:"गणपती बाप्पा मोरया",
      diyaMsg:"दिवा प्रज्वलित झाला. मंगल प्रकाश आपल्या जीवनात राहो. 🪔",
      flowerMsg:"गणेशजींना फुले अर्पण केली. 🌸", bellMsg:"घंटेचा मंगल नाद घुमला. 🔔",
      incenseMsg:"धूप अर्पण केली. वातावरण पवित्र आणि शांत राहो. 🕯️",
      prasadMsg:"गणेशजींना मोदकाचा नैवेद्य अर्पण केला. 🍬",
      chantMsg:"ॐ गं गणपतये नमः — मंत्रजप पूर्ण. 🕉️",
      wishMsg:"आपली मनोकामना श्रद्धेने अर्पण केली. गणपती बाप्पा मोरया! 🙏",
      emptyWish:"कृपया तुमची मनोकामना लिहा. 🙏", complete:"आपली पूजा पूर्ण झाली. सुख, शांती आणि आरोग्याच्या मंगलकामना. 🌺",
      placeholder:"तुमची मनोकामना येथे लिहा…"
    }
  };

  let lang = localStorage.getItem("ganeshLang") || "hi";
  let completed = new Set();
  let aartiActive = false;
  let audioContext = null;
  let audioOn = false;
  let toastTimer = null;

  const $ = id => document.getElementById(id);
  const t = key => (translations[lang] && translations[lang][key]) || translations.hi[key] || key;

  function applyLanguage() {
    document.documentElement.lang = lang === "gu" ? "gu" : lang === "mr" ? "mr" : "hi";
    document.querySelectorAll("[data-i18n]").forEach(el => {
      const key = el.getAttribute("data-i18n");
      if (translations[lang][key]) el.innerHTML = translations[lang][key];
    });
    $("wishInput").placeholder = t("placeholder");
    $("aartiSoundBtn").textContent = audioOn ? t("soundOff") : t("soundOn");
    updateProgress();
  }

  function showToast(message) {
    const el = $("toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
  }

  function updateProgress() {
    $("progressText").textContent = `${completed.size} / 7`;
    $("progressFill").style.width = `${Math.min(100, completed.size / 7 * 100)}%`;
  }

  function mark(key, message, button) {
    completed.add(key);
    if (button) button.classList.add("active");
    $("status").textContent = message;
    updateProgress();
    showToast(message);
  }

  function makeSound(kind = "soft") {
    if (!audioOn && kind !== "bell") return;
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      if (!audioContext) audioContext = new Ctx();
      const osc = audioContext.createOscillator();
      const gain = audioContext.createGain();
      osc.connect(gain); gain.connect(audioContext.destination);
      const now = audioContext.currentTime;
      osc.type = kind === "bell" ? "sine" : "triangle";
      osc.frequency.setValueAtTime(kind === "bell" ? 660 : 440, now);
      if (kind === "bell") osc.frequency.exponentialRampToValueAtTime(990, now + .12);
      gain.gain.setValueAtTime(.0001, now);
      gain.gain.exponentialRampToValueAtTime(.14, now + .02);
      gain.gain.exponentialRampToValueAtTime(.0001, now + (kind === "bell" ? 1.1 : .35));
      osc.start(now); osc.stop(now + (kind === "bell" ? 1.2 : .4));
    } catch (_) {}
  }

  function showerFlowers() {
    const holder = $("petals");
    const symbols = ["🌸", "🌼", "🌺", "🌻"];
    for (let i = 0; i < 15; i++) {
      const petal = document.createElement("span");
      petal.className = "petal";
      petal.textContent = symbols[Math.floor(Math.random() * symbols.length)];
      petal.style.left = `${5 + Math.random() * 90}%`;
      petal.style.animationDelay = `${Math.random() * .65}s`;
      petal.style.fontSize = `${17 + Math.random() * 11}px`;
      holder.appendChild(petal);
      setTimeout(() => petal.remove(), 3400);
    }
  }

  function lightDiya(button) {
    $("lamps").classList.add("lit");
    makeSound("soft");
    mark("diya", t("diyaMsg"), button);
  }

  function offerFlower(button) {
    showerFlowers();
    makeSound("soft");
    mark("flower", t("flowerMsg"), button);
  }

  function ringBell(button) {
    audioOn = true;
    makeSound("bell");
    mark("bell", t("bellMsg"), button);
  }

  function offerIncense(button) {
    makeSound("soft");
    mark("incense", t("incenseMsg"), button);
  }

  function offerPrasad(button) {
    makeSound("soft");
    mark("prasad", t("prasadMsg"), button);
  }

  function chant(button) {
    makeSound("soft");
    mark("chant", t("chantMsg"), button);
  }

  function startAarti(button) {
    aartiActive = true;
    completed.add("aarti");
    $("aartiPanel").hidden = false;
    button.classList.add("active");
    $("status").textContent = t("aartiStarted");
    updateProgress();
    showerFlowers();
    audioOn = true;
    makeSound("bell");
    $("aartiSoundBtn").textContent = t("soundOff");
  }

  function finishAarti() {
    aartiActive = false;
    $("aartiPanel").hidden = true;
    $("aarti").classList.remove("active");
    $("status").textContent = t("complete");
    showToast(t("complete"));
  }

  function toggleSound() {
    audioOn = !audioOn;
    $("aartiSoundBtn").textContent = audioOn ? t("soundOff") : t("soundOn");
    if (audioOn) makeSound("bell");
  }

  function resetPooja() {
    completed = new Set();
    aartiActive = false;
    audioOn = false;
    $("aartiPanel").hidden = true;
    $("lamps").classList.remove("lit");
    document.querySelectorAll(".active").forEach(el => el.classList.remove("active"));
    $("status").textContent = t("ready");
    updateProgress();
    showToast(t("ready"));
  }

  document.querySelectorAll("[data-action]").forEach(button => {
    button.addEventListener("click", () => {
      const action = button.dataset.action;
      if (action === "diya") lightDiya(button);
      if (action === "flower") offerFlower(button);
      if (action === "bell") ringBell(button);
      if (action === "aarti") startAarti(button);
      if (action === "incense") offerIncense(button);
      if (action === "prasad") offerPrasad(button);
      if (action === "chant") chant(button);
      if (action === "reset") resetPooja();
    });
  });

  $("finishAartiBtn").addEventListener("click", finishAarti);
  $("aartiSoundBtn").addEventListener("click", toggleSound);

  $("wishBtn").addEventListener("click", () => {
    const value = $("wishInput").value.trim();
    if (!value) {
      $("status").textContent = t("emptyWish");
      $("wishInput").focus();
      return;
    }
    $("wishInput").value = "";
    mark("wish", t("wishMsg"), $("wishBtn"));
  });

  $("languageSelect").value = lang;
  $("languageSelect").addEventListener("change", event => {
    lang = event.target.value;
    localStorage.setItem("ganeshLang", lang);
    applyLanguage();
  });

  // Register service worker for installable/offline PWA behavior.
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("service-worker.js").catch(() => {});
    });
  }

  applyLanguage();
})();
